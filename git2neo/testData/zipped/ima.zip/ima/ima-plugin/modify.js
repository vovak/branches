var titleElements = document.getElementsByClassName('title');

for(var i=0; i<titleElements.length;++i){
    title = titleElements[i];
    lyricsLink = title.getElementsByTagName("a")[0];
    if (lyricsLink) title = lyricsLink;
    title.innerHTML += " In My Ass";
}


